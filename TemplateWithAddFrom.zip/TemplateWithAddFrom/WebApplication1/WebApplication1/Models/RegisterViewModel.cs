﻿ using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Models
{
    public class RegisterViewModel
    {
        [Required]
        [RegularExpression(@"^[a-zA-Z ]*$", ErrorMessage = "Name Should be in Alphabets")]
        public string UserName { get; set; }

        [Required]
        [RegularExpression(@"^[0-9]+$", ErrorMessage = "Phone should be Digits")]
        public string Phone { get; set; }

        [Required]
        public string Address { get; set; }

        [Required, EmailAddress]
        public string Email { get; set; }
    }
}
