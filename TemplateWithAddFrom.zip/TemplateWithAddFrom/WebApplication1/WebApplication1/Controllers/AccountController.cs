﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;


// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebApplication1.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserManager<IdentityUser> _userManager;
        private readonly SignInManager<IdentityUser> _signInManager;
        public static List<RegisterViewModel> List = new List<RegisterViewModel>();


        public AccountController(UserManager<IdentityUser> userManager, SignInManager<IdentityUser> signInManager)
        {
            _userManager = userManager;
            _signInManager = signInManager;
        }
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Register(RegisterViewModel collection)
        {
            if(!ModelState.IsValid) return View(collection);
            RegisterViewModel person = new RegisterViewModel();
            person.UserName = collection.UserName;  
            person.Address = collection.Address;
            person.Phone = collection.Phone;
            person.Email = collection.Email;

            List.Add(person);
            return RedirectToAction("ShowAll");

        }

        public IActionResult ShowAll()
        {
            return View(List);
        }
    }
}

