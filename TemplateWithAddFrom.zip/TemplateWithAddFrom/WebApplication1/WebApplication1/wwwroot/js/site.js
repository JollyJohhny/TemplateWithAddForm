﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

$('#theme').on("change", function () {
    var item = $("#theme option:selected").text();

    /*$.ajax({
        type: "POST",
        url: "/Home/SetTheme",

        contentType: "application/json",
        dataType: "json",
        success: function (respone) {
            var dvItems = $("#dvItems");
            dvItems.empty();
            $.each(respone, function (i.item) {
                var $tr = $('<li>').append(item).appendTo(dvItems);
            });
        },
        failure: function (response) {
            alert(response);
        }
    });*/

    $.post("Home/SetTheme",
        {
            data: item
        });
    
});